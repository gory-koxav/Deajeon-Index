def main():
    print("Hello from daejeon-kospi-index!")


if __name__ == "__main__":
    main()
